This document is written for the guide of the T3Q.ai platform, 
and T3Q Co., Ltd. has the legal authority for matters other than the stated copyright.

The following components are under Creative Commons Attribution 4.0 International license
- dataset components


----------------------------------------------------------------------
- 데이터셋 라이선스: CC BY 4.0
- 코드 라이선스:
----------------------------------------------------------------------
